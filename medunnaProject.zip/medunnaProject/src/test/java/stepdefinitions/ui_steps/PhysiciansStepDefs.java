package stepdefinitions.ui_steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PhysiciansStepDefs {


    @When("user click on {string} button")
    public void user_click_on_button(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @When("user provides valid {string} id in SSN box")
    public void user_provides_valid_id_in_ssn_box(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @When("user click {string} Button")
    public void user_click_button(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @Then("user views an existing registered person")
    public void user_views_an_existing_registered_person() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
}
