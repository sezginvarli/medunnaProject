package stepdefinitions.ui_steps;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.Select;
import pages.HomeAndSigninPage;
import pages.StaffPage;
import pojos.Registrant;
import utilities.JSUtils;
import utilities.ReusableMethods;

import java.sql.Driver;

public class StaffStepDefs_MT {

    HomeAndSigninPage homeAndSigninPage = new HomeAndSigninPage();
    StaffPage staffPage = new StaffPage();
    Registrant registrant=new Registrant();
    Faker faker = new Faker();

    @When("user clicks on Search Patient button")
    public void user_clicks_on_search_patient_button() {
        staffPage.searchPatientButton.click();
    }

    @When("user search patient with {string}")
    public void user_search_patient_with(String SSN) {
        staffPage.searchPatientWithSsn.sendKeys(SSN);
    }

    @When("user clicks on View button")
    public void user_clicks_on_view_button() {
        ReusableMethods.waitForClickablility(staffPage.viewButtonAfterSearchingPatient,3).click();
    }

    @Then("Verify view portal is displayed")
    public void verify_view_portal_is_displayed() {
        Assert.assertTrue(staffPage.viewPortal.isDisplayed());
    }


    @And("Verify All Patient Info is displayed")
    public void verifyAllPatientInfoIsDisplayed() {

        Assert.assertTrue(staffPage.ssnInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.firstNameInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.lastNameInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.birthDateInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.phoneInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.emailInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.genderInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.bloodGroupInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.adressInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.descriptionInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.createdDateInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.userInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.countryInfoTitle.isDisplayed());
        Assert.assertTrue(staffPage.stateCityInfoTitle.isDisplayed());


    }

    @And("user clicks on Edit button")
    public void userClicksOnEditButton() {
        ReusableMethods.waitForVisibility(staffPage.editButtonAfterSearchingPatientPage,3).click();
    }

    @And("user sends a new firstname")
    public void userSendsANewFirstname() {
        ReusableMethods.waitForVisibility(staffPage.patientFirstNameBox,1).clear();
        staffPage.patientFirstNameBox.sendKeys(Faker.instance().name().firstName());
    }

    @And("user sends a new lastname")
    public void userSendsANewLastname() {
        staffPage.patientLastNameBox.clear();
        staffPage.patientLastNameBox.sendKeys(Faker.instance().name().lastName());
    }

    @And("user sends a new birthday")
    public void userSendsANewBirthday() {
        // DATE FORMAT !!!
    }

    @And("user sends a new email")
    public void userSendsANewEmail() {
        staffPage.patientEmailBox.clear();
        staffPage.patientEmailBox.sendKeys(Faker.instance().internet().emailAddress());
    }

    @And("user sends a new phone")
    public void userSendsANewPhone() {
        // PHONE NUMBER - 10 DİGİTS !!!
    }

    @And("user select a new gender")
    public void userSelectANewGender() {
        Select select = new Select(staffPage.patientGenderDropDown);
        select.selectByIndex(2);
    }

    @And("user select a new blood group")
    public void userSelectANewBloodGroup() {
        Select select = new Select(staffPage.patientBloodGroupDropDown);
        select.selectByVisibleText("AB+");
    }

    @And("user sends a new address")
    public void userSendsANewAddress() {
        staffPage.patientAdressBox.clear();
        staffPage.patientAdressBox.sendKeys(Faker.instance().address().fullAddress());
    }

    @And("user sends a new description")
    public void userSendsANewDescription() {
        staffPage.patientDescriptionBox.clear();
        staffPage.patientDescriptionBox.sendKeys(Faker.instance().job().field());
    }

    @And("user select a new user")
    public void userSelectANewUser() {
        Select select = new Select(staffPage.patientUserDropDown);
        select.selectByIndex(4);
    }

    @And("user select a new country")
    public void userSelectANewCountry() {
        Select select = new Select(staffPage.patientCountryDropDown);
        select.selectByVisibleText("Turkiye");

    }

    @And("user select a new state-city")
    public void userSelectANewStateCity() {
        ReusableMethods.waitFor(2);
        Select select = new Select(staffPage.patientCityStateDropDown);
        select.selectByIndex(0);
    }

    @And("user clicks on Save button")
    public void userClicksOnSaveButton() {
        staffPage.saveButton.click();

    }

    @Then("Verify {string} pop up")
    public void verifyPopUp(String popUpMessage) {

        ReusableMethods.waitForVisibility(staffPage.newPatientCreatedMessage,3);
        String actualMessage = staffPage.newPatientCreatedMessage.getText();
        Assert.assertTrue(actualMessage.contains(popUpMessage));
    }

    @And("user clicks on Show Appointments button")
    public void userClicksOnShowAppointmentsButton() {
        ReusableMethods.waitForClickablility(staffPage.showAppointmentsButtonAfterSearchingPatientPage,3).click();

    }

    @And("user clicks on Show Tests button")
    public void userClicksOnShowTestsButton() {
        ReusableMethods.waitForClickablility(staffPage.showTestsButton,3).click();
    }

    @And("user clicks on View Results button")
    public void userClicksOnViewResultsButton() {
        ReusableMethods.waitForClickablility(staffPage.viewResultsButton,3).click();
    }
}
