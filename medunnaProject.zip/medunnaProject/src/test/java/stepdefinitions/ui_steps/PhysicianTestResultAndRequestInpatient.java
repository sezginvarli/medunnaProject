package stepdefinitions.ui_steps;

public class PhysicianTestResultAndRequestInpatient {
}
